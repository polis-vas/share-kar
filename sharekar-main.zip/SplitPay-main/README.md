# SplitPay

Hosted on - https://splitpay-iwp.herokuapp.com/
